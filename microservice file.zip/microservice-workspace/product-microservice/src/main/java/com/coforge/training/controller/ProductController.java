package com.coforge.training.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.coforge.training.Repository.ProductRepo;
import com.coforge.training.model.Product;
import com.coforge.training.service.ProductService;

@RequestMapping("/users")
@RestController
@CrossOrigin(origins="http://localhost:4200")
public class ProductController {


	@Autowired
	private ProductService productService;
	//private ProductRepo repo;

	//	@GetMapping(value="/products/{productId}")
	//	public List<Product>getProductsByEmpId(@PathVariable int productId) {
	//		System.out.println("ProductId------" + productId);
	//		List<Product> empProductList = productService.findProductsByEmpId(productId);
	//		return empProductList;
	//
	//	}  
	
	@GetMapping("/products")  
	private List<Product> getAllProducts()   
	{  
	return productService.getAllProducts();  
	}  

	@PostMapping("/products")
	public Product save(@RequestBody() Product product)
	{
		return productService.save(product);
	}
	@GetMapping("products/{id}")
	//@GetMapping(value="/products/{productId}")
	public Product getProduct(@PathVariable("id") Long productId) {
		return productService.getProduct(productId);
	}

	@PutMapping("/products/{id}")
	public ResponseEntity<Product> update(@RequestBody Product product, @PathVariable("id") long id) {
		Product res=productService.update(product, id);
		return ResponseEntity.ok().body(res);
	}

	@DeleteMapping("products/{id}")
	public void delete(@PathVariable("id") Long id) {

		productService.deleteUser(id);
	}
}
