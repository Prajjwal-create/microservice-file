package com.coforge.training.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.stereotype.Service;

import com.coforge.training.Repository.ProductRepo;
import com.coforge.training.model.Product;
@Service
public class ProductService {
	
	@Autowired
	private ProductRepo repo;
	
//	
	//private List<Product> getProductList(){
		
//		
//		List<Product> productList = new ArrayList<>();
//		productList.add(new Product(1, "Shoe", "1000"));
//		productList.add(new Product(2:, "laptop", "3244"));
//		productList.add(new Product(3, "mouse", "5467"));
//		productList.add(new Product(4, "bread", "20"));
//		productList.add(new Product(5, "ribbon", "456"));
//		
//		return productList;
//		}
//	
//	public List<Product> findProductsByEmpId(int productId){
//
//		List<Product> productList = getProductList();
//
//		List<Product> empProductList = new ArrayList<>();
//
//		for(Product product : productList) {
//
//		if(product.getProductId() == (productId))
//		empProductList.add(product);
//		}
//		return empProductList;
//		}

	
	
	public Product save(Product product) {
		// TODO Auto-generated method stub
		return repo.save(product);
	}
	
	  public void saveUser(Product product) {
	       repo.save(product);
	    }

	public Product getProduct(Long productId) {
	
		return repo.findById(productId).get();
		
	}

	public void deleteUser(Long id) {
		// TODO Auto-generated method stub
	   	repo.deleteById(id);
	}

	public Product update(Product product, long id) {
		// TODO Auto-generated method stub
		return repo.save(product);
	}

//	public List<Product> findAll() {
//		return repo.findAll();
//		//return null;
//	}

	public List<Product> getAllProducts() {
		List<Product> product = new ArrayList<Product>();  
		repo.findAll().forEach(product1 -> product.add(product1));  
		return product;  
	}
}
