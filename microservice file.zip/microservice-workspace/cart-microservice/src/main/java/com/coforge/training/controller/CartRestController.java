package com.coforge.training.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
@RestController
@RequestMapping("/cart")
public class CartRestController {

	
	@GetMapping("/getData")
	public String getCartData() {
		
		return "Returing Data From CART-SERVICE";
	}
}
