


package com.coforge.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.coforge.training.model.Item;
import com.coforge.training.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@RestController
@RequestMapping("/user")
public class UserRestController {
	
	private Logger log = LoggerFactory.getLogger(UserRestController.class);
	
	@Autowired
	private UserService uService;
	
	@GetMapping("/allItems")
	public ResponseEntity<List<Item>> getItemInfo(){
		log.info("Inside User microservices");
		return uService.getAllItems();
	}

}
