package com.coforge.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.coforge.training.controller.UserRestController;
import com.coforge.training.model.Item;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Service
public class UserService  {

	private Logger log = LoggerFactory.getLogger(UserService.class);
	@Autowired
	private ItemServiceClient itemServiceClient;

	public ResponseEntity<List<Item>> getAllItems()
	{
		return itemServiceClient.getAllItems(); // consume Item Microservice using feign Clint

	}
}
