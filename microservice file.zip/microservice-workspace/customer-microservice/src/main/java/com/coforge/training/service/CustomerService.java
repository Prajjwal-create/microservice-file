package com.coforge.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

import com.coforge.training.model.Product;


@Service
public class CustomerService {

	@Autowired
	private RestTemplate restTemplate;

	/*restTemplate.exchange() is the method used for making remote call to another microservice.*/

	public List<Product> showEmployees(@PathVariable("id") int id) {
	System.out.println(id);

	// Invokes Account Microservice
	// "http://localhost:9000/accounts/{empId}" -- actually we invoke
	// ms in above format
	// To avoid hardcoding of URL , we use netflix Ribbon Service which can be integrated with
	// Eureka -- Ribbon Load Balancer
      List<Product> products = restTemplate.exchange(
	"http://Product/products/{productId}", HttpMethod.GET, null, new
	ParameterizedTypeReference<List<Product>>(){}, id).getBody();
	return products;
		}
		}
